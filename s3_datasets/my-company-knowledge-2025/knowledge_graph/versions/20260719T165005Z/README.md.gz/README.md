# Thai Administrative Law Knowledge Graph

Generated from the shared S3 legal corpus for use by the two Smart Court AI
instances and for later import into Dify or a graph database.

## Trust model

1. Statutes and official court-jurisdiction records
2. Official manuals and institutional knowledge documents
3. FAQ and call-centre answers
4. Media and general explanatory material

Lower-numbered tiers override higher-numbered tiers when sources conflict.
Every legal answer must remain traceable to an `EvidenceChunk`.

## Node types

- `LegalInstrument`
- `Section`
- `UnresolvedSectionReference`
- `Clause`
- `AdministrativeCourt`
- `Province`
- `Document`
- `EvidenceChunk`
- `QuestionAnswer`

## Edge types

- `HAS_SECTION`
- `MENTIONS_SECTION`
- `MENTIONS_CLAUSE`
- `CITES`
- `SUPPORTED_BY`
- `HAS_EVIDENCE`
- `DESCRIBES`
- `HAS_JURISDICTION_OVER`

## Files

- `nodes.csv` and `edges.csv`: graph database imports
- `graph.json` and `graph.jsonl`: portable graph representations
- `jurisdiction_graph_context.md`: curated RAG document
- `validation_report.json`: generation statistics, rules, and warnings

The uncompressed graph files are retained in the build workspace for QA. In S3
the machine-readable artifacts are stored as gzip files so the Bedrock data
source does not treat the entire graph as duplicate RAG prose.
